# UniTech Hub

Hostingga tayyor statik veb-sayt.

## Fayllar
- index.html — asosiy sahifa
- style.css — dizayn

## Hosting
Bu loyiha server talab qilmaydi. Netlify, Vercel, GitHub Pages yoki oddiy hostingga `index.html` va `style.css` fayllarini yuklash kifoya.

## Muhim
`hello@unitech.uz` demo email sifatida qo'yilgan. Ishlatishdan oldin uni haqiqiy emailingizga almashtiring.
